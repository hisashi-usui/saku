#!/usr/bin/perl

unlink "ato.txt";
open ADD, ">>ato.txt";
print ADD "cdy.evokeCS(\"";
open IN, "moto.txt";
while($_=<IN>){
	s/\"/\\"/g;
	s/\n//g;
	printf ADD $_;
}
close IN;
	print ADD " \");";
close ADD;

